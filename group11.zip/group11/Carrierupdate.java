package application;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import java.sql.*;


public class Carrierupdate {
    private Stage stage;
    private Scene scene;
    private AnchorPane root;

    @FXML
    Button buttonlogout;

    @FXML
    Button Update;

    @FXML
    TextField usertext;

    @FXML
    PasswordField password;

    public void log_out(ActionEvent event) throws IOException{
        AnchorPane root = FXMLLoader.load(getClass().getResource("hello-view.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void update(ActionEvent event) throws IOException{
	    	try {
	    	
	    		String user = usertext.getText();
	    	    String pass = password.getText();
	    	    Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/carriers", "root", "Hh123456!");
	    	    PreparedStatement checkUser = connect.prepareStatement("SELECT username FROM carrierlist WHERE username = ? AND password = ?");
	    	    checkUser.setString(1, user);
	    	    checkUser.setString(2, pass);
	    	    ResultSet resultSet = checkUser.executeQuery();
	    	    if (!resultSet.next()) {
	    	        PreparedStatement insert = connect.prepareStatement("INSERT INTO carrierlist (username, password) VALUES (?, ?)");
	    	        insert.setString(1, user);
	    	        insert.setString(2, pass);
	    	        insert.executeUpdate();
	    	    } else {
	    	        // if the combination exists, deletes carriers
	    	        PreparedStatement delete = connect.prepareStatement("DELETE FROM carrierlist WHERE username = ? AND password = ?");
	    	        delete.setString(1, user);
	    	        delete.setString(2, pass);
	    	        delete.executeUpdate();
	    	    }

	    	    connect.close();
	    	    checkUser.close();
	    	    resultSet.close();

	    	} catch (SQLException except) {
	    	    except.printStackTrace();
	    	}
    }
}
