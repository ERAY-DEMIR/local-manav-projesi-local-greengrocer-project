package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.control.Label;

public class Products {
	
	@FXML
    private TextField availableproduct;

    @FXML
    private TextField kilo;

    @FXML
    private TextField kilogram;

    @FXML
    private TextField name;

    @FXML
    private Button new_product;

    @FXML
    private TextField price;

    @FXML
    private TextField price_update;

    @FXML
    private Button product_updatebutton;

    @FXML
    private TextField producttype;

    @FXML
    private TextField threshold;

    @FXML
    private Label warn_button_add;

    @FXML
    private Label warn_kg_add;

    @FXML
    private Label warn_name_add;

    @FXML
    private Label warn_price_add;

    @FXML
    private Label warn_price_update;

    @FXML
    private Label warn_product_kg;

    @FXML
    private Label warn_product_update;

    @FXML
    private Label warn_threshold_add;

    @FXML
    private Label warn_type_add;

    @FXML
    private Label warn_update_button;
    
    @FXML
    private Button menubutton;
    
    private Stage stage;
	private Scene scene;
	private Parent root;
    
    public void addproduct(ActionEvent event) {
         String product_type= producttype.getText();
         String pro_name=name.getText();
         String prices= price.getText();
         String kilograms= kilo.getText();
         String Threshold=threshold.getText();
         
         if(!product_type.equals("Fruit") || !product_type.equals("Vegetable"))
         {
        	 warn_type_add.setText("Please enter Fruit or Vegetable");
         }
         if(pro_name.length()>0)
         {
        	 char character= pro_name.charAt(0);
        	 if(Character.isLowerCase(character))
        	 {
        		 warn_name_add.setText("Please enter uppercase");
        	 }
         }
         else if (pro_name.length()==0)
         {
        	 warn_name_add.setText("Empty ");
         }
         
	         double value = Double.parseDouble(prices);	// if user enter name or enter value with ",",you will see exception error in console and informations will not be set to database	
	         double kg= Double.parseDouble(kilograms);  // if user enter name or enter value with ",",you will see exception error in console and informations will not be set to database	
	         double thres= Double.parseDouble(Threshold);    // if user enter name or enter value with ",",you will see exception error in console and informations will not be set to database	
	         if (value<=0)
	         {
	        	 warn_price_add.setText("Entered negative or 0 value");
	         }
	         else if(prices.length()==0)
	         {
	        	 warn_price_add.setText("Empty");
	         }
	         else if(kg<=0)
	         {
	        	 warn_kg_add.setText("Entered negative or 0 value");
	         }
	         
	         else if(thres<=0)
	         {
	        	 warn_threshold_add.setText("Entered negative or 0 value");
	         }
	         else if(thres!= kg/2)
	         {
	        	 warn_threshold_add.setText("Threshold value must be equal to half of kg value");
	         }
	         else
	         {
	        		 try {
	        			 Connection connect3 = DriverManager.getConnection("jdbc:mysql://localhost:3306/products", "root", "Hh123456!");
	        			    java.sql.Statement smt1 = connect3.createStatement();
	        			    ResultSet rs = smt1.executeQuery("SELECT * FROM producttable ");

	        			    boolean Exists = false;
	        			    while (rs.next()) {
	        			        String existingName = rs.getString("product_name");
	        			        if (existingName.equals(pro_name)) {
	        			            Exists = true;
	        			            warn_button_add.setText("Product name already exists. Please use the update button.");
	        			            break;  
	        			        }
	        			    }
	        			    if (!Exists) {
	        			        // Product name doesn't exist, proceed with insertion
	        			        PreparedStatement insert = connect3.prepareStatement("INSERT INTO producttable (product_type, product_name, price, stock, threshold) VALUES (?, ?, ?, ?, ?)");
	        			        insert.setString(1, product_type);
	        			        insert.setString(2, pro_name);
	        			        insert.setDouble(3, value);
	        			        insert.setDouble(4, kg);
	        			        insert.setDouble(5, thres);
	        			        insert.executeUpdate();
	        			        warn_button_add.setText("Successfully added to database");
	        			    }
	        			    connect3.close();
	        			    rs.close();
	        	 }catch (SQLException d) {
	                 d.printStackTrace();
	             }
	         }
         }
    
    
    public void updating(ActionEvent event) {
    	String product_name= availableproduct.getText();
    	if(product_name.length()>0)
        {
	       	 char character= product_name.charAt(0);
	       	 if(Character.isLowerCase(character))
	       	 {
	       		 warn_product_update.setText("Please enter uppercase");
	       	 }
        }
        else if (product_name.length()==0)
        {
       	     warn_product_update.setText("Empty ");
        }
        String weight= kilogram.getText();
        String cost= price_update.getText();
        
        Double kg= Double.parseDouble(weight);  // if user enter name or enter value with ",",you will see exception error in console and informations will not be set to database	
        Double price= Double.parseDouble(cost);   // if user enter name or enter value with ",",you will see exception error in console and informations will not be set to database	
        if(kg<=0)
        {
       	    warn_product_kg.setText("Entered negative or 0 value");
        }
        if(price<=0)
        {
        	warn_price_update.setText("Entered negative or 0 value");
        }
        else
        {
        	try {
        	Connection c= DriverManager.getConnection("jdbc:mysql://localhost:3306/products", "root", "Hh123456!");
			 java.sql.Statement stmt= c.createStatement();
			 ResultSet result=stmt.executeQuery("SELECT * FROM producttable ");
			 boolean productFound = false;

			 while (result.next()) {
			     String product = result.getString("product_name").trim();  
			     if (product.equalsIgnoreCase(product_name.trim())) {  
			         productFound = true;
			         Double kilo = result.getDouble("stock");
			         Double total_kg = kilo + kg;
			         
			         PreparedStatement update = c.prepareStatement("UPDATE producttable SET price = ?, stock = ?, threshold = ? WHERE product_name = ?");
			         update.setDouble(1, price);
			         update.setDouble(2, total_kg);
			         update.setDouble(3, total_kg / 2);
			         update.setString(4, product_name.trim());
			         update.executeUpdate();
			         
			         warn_update_button.setText("Successfully updated");
			         break;  // Exit the loop once the product is found and updated
			     }
			 }

			 if (!productFound) {
			     warn_update_button.setText("Your product is not available");
			 }
			 c.close();
			 result.close();
			 
        	}catch (SQLException d) {
                d.printStackTrace();
            }
        }
    }
    
    public void gomenu(ActionEvent event) throws IOException {
    	AnchorPane root = FXMLLoader.load(getClass().getResource("owner.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();   
    }
}
