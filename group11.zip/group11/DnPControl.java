package application;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ChoiceBox;
import java.time.LocalTime;
import java.sql.*;

public class DnPControl{
	
	private Stage stage;
	private Scene scene;
	private AnchorPane root;
	
	
	@FXML
	private DatePicker myDatePicker;
	@FXML
	private Label myLabel;
	
	private LocalDate minDate = LocalDate.now();
	private LocalDate maxDate = LocalDate.now().plusDays(2);
	
	
	
	
	@FXML
	TextField phone;
	
	@FXML
	TextField CardNoTextField;
	
	@FXML
	TextField CVVTextField;
	
	@FXML
	TextField CardDateField;
 
	@FXML
	Button SubmitPaymentButton;
	
	@FXML
	Button SubmitDateButton;
	
	@FXML
	Label user;
	
	@FXML
	Label warn_cardno;
	
	@FXML
	Label warn_cvv;
	
	@FXML
	Label warn_date;
	
	@FXML
	Label warn_complete;
	
	@FXML
	Label warn;
	
	@FXML
	Label warn_error;
	
	@FXML
	Label warn_phone;
	
	@FXML
	Label warning;
	
	
	/*
	public void getDate(ActionEvent event) {
	  
	  LocalDate myDate = myDatePicker.getValue();
	  String ChosenDate = myDate.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
	  myLabel.setText(ChosenDate);
	  
	}
	*/
	
	public void displayName(String username){
		user.setText(username);
	}
	public void checkDate(ActionEvent event) {
		  
		LocalDate myDate = myDatePicker.getValue();
		int datechecker =  myDate.compareTo(maxDate); 
		int datechecker2 = minDate.compareTo(myDate);
		String ChosenDate = null;
		if(datechecker < 1) {
			ChosenDate = myDate.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
			myLabel.setText(ChosenDate);
		}else if(datechecker == 0) {	
			ChosenDate = myDate.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
			myLabel.setText(ChosenDate);;
		}else {
			myLabel.setText("Invalid Date");
		}
		if(datechecker2 > 0) {
			myLabel.setText("Invalid Date");
		}
		
	}
	public void datebutton (ActionEvent event)throws IOException // in this part user completes order 
	{
		
	    	String phone_no= phone.getText();
	    	 boolean a= phone_no.matches(".*\\d.*");
			 if(!a || phone_no.length()<10){
				 warn_phone.setText("Invalid phone number");
			 }
			 else
			 {
				 String date= myLabel.getText();
				 if ("Invalid Date".equals(date) || "Date".equals(date))
				 {
					 warn.setText("Invalid choice");
				 }
				 else
				 {
					 String the_user=user.getText();
					 int d=0;
					 try {
						 
						 Connection connect= DriverManager.getConnection("jdbc:mysql://localhost:3306/infos", "root", "Hh123456!");
						 java.sql.Statement smt1= connect.createStatement();
						 ResultSet resultSet=smt1.executeQuery("SELECT username,name,surname,address FROM registertable ");
			             while(resultSet.next())
			             {
			            	 String usern= resultSet.getString("username");
			            	 String Name= resultSet.getString("name");
			            	 String SurName= resultSet.getString("surname");
			            	 String Address= resultSet.getString("address");
			            	 if(usern.equals(the_user))
			            	 {
			            		 try {
			            		 Connection connect1= DriverManager.getConnection("jdbc:mysql://localhost:3306/finalizeorder", "root", "Hh123456!");
					             PreparedStatement preparedStatement1= connect1.prepareStatement("SELECT username, name ,surname,adress FROM orderinfos  ");
					             ResultSet resultSet1=preparedStatement1.executeQuery();
					             PreparedStatement Insert= connect1.prepareStatement("INSERT INTO orderinfos (username,name,surname,adress,phone,products,kg,tax,tax_exclude,total_price,payment, isselected, delivery_day) Values(?,?,?,?,?,?,?,?,?,?,?,?,?)"); 
					             Insert.setString(1,the_user);
					             Insert.setString(2,Name);
					             Insert.setString(3,SurName);
					             Insert.setString(4,Address);
					             
					              //in this try catch we are adding shopping cart to database that keeps orders
									    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/orderinfo", "root", "Hh123456!");
							            PreparedStatement ps = con.prepareStatement("SELECT * FROM selectlist ");
							            ResultSet res = ps.executeQuery();
							            Double resulta=0.00; // for calculate tax
							            Double resultb=0.00;//used for keep total price
							            String comma=",";
							            StringBuilder productsBuilder = new StringBuilder();
							            StringBuilder kgBuilder = new StringBuilder();
							            
							            while(res.next())
							            {
							            	double getPrice= res.getDouble("totalprice");
							            	resulta+= getPrice;
							            	resultb+= getPrice;
							            	String getproducts= res.getString("productname");
							            	productsBuilder.append(getproducts).append(comma);
							            	double getkg = res.getDouble("kg");
							                kgBuilder.append(String.valueOf(getkg)).append(comma);
							           
							            }
							            String products = productsBuilder.toString().replaceAll(",$", "");
							            String kgs = kgBuilder.toString().replaceAll(",$", "");
							            double tax=resulta/5;
							            resulta-=tax;
							            
								        Insert.setString(6,products);
								        Insert.setString(7,kgs);
								        Insert.setDouble(8,tax);
								        Insert.setDouble(9,resulta);
								        Insert.setDouble(10,resultb);
										String isselect = "0";
										String datelabel = myLabel.getText(); 			
										Insert.setString(5, phone_no);
										Connection connect4 = DriverManager.getConnection("jdbc:mysql://localhost:3306/creditcards", "root", "Hh123456!");
								        PreparedStatement check = connect4.prepareStatement("SELECT * FROM creditinfo");
								        ResultSet r = check.executeQuery();
								        while(r.next())
								        {
								        	String user_credit=r.getString("username");
								        	String credit;
								        	if(user_credit.equals(the_user))
								        	{
								        		credit="1";
								        		Insert.setString(11, credit);
								        	}
								        	else
								        	{
								        		credit="0";
								        		Insert.setString(11, credit);
								        	}
								        }
								        
										Insert.setString(12, isselect);
										Insert.setString(13, datelabel);
										Insert.executeUpdate(); 
										connect4.close();
										connect1.close();
								        con.close();
			            		 }catch (SQLException g) {
					                    g.printStackTrace();
					                }
			            	 }
			             }
			             connect.close();
					 }catch (SQLException except) {
		                    except.printStackTrace();
		                }
						FXMLLoader loader = new FXMLLoader(getClass().getResource("Aftercomplete.fxml"));
						AnchorPane root = loader.load();
						aftercomplete b = loader.getController();
						b.displayName(the_user);
						stage = (Stage)((Node)event.getSource()).getScene().getWindow();
						scene = new Scene(root);
						stage.setScene(scene);
						stage.show(); 
				 }
			 }								        
					             
			             
	}
	public void completeorder(ActionEvent event)throws IOException // in this part user saves credit card informations to database
	{
		try {
			 Connection connect4 = DriverManager.getConnection("jdbc:mysql://localhost:3306/creditcards", "root", "Hh123456!");
	         PreparedStatement checkExisting = connect4.prepareStatement("SELECT * FROM creditinfo");
	         ResultSet res = checkExisting.executeQuery();
			 String cardnumber= CardNoTextField.getText();
			 String cvv_num= CVVTextField.getText();
			 String carddate= CardDateField.getText();
			 String username = user.getText();
			 boolean a= cardnumber.matches(".*\\d.*");
			 if(!a){
				 warn_cardno.setText("Invalid card no");
			 }
			 boolean b= cvv_num.matches(".*\\d.*");
			 if(!b){
				 warn_cvv.setText("Invalid cvv");
			 }
			 boolean c= carddate.matches(".*\\d.*");
			 if(!c){
				 warn_date.setText("Invalid date");
			 }
			 if (a==true && b==true && c==true){
				 PreparedStatement insert = connect4.prepareStatement("INSERT INTO creditinfo (cardno,cvv,date,username) VALUES (?, ?, ?,?)");
				 insert.setString(1, cardnumber);
                 insert.setString(2, cvv_num);
                 insert.setString(3, carddate);
                 insert.setString(4, username);
                 warn_complete.setText("You completed your shopping successfully");
                 insert.executeUpdate();
			 }
			 checkExisting.close();
			 res.close();
			 connect4.close();
		 } catch (SQLException d) {
             d.printStackTrace();
         }
		
		
	}
	
	public void switchToSummary(ActionEvent event) throws IOException{
		String username = user.getText();
		String select_date=myLabel.getText();
		if(select_date!="Date" && select_date!="Invalid Date")
		{
			FXMLLoader loader = new FXMLLoader(getClass().getResource("Summary.fxml"));
			AnchorPane root = loader.load();
			summary sum = loader.getController();
			summary date= loader.getController();
			sum.displayName(username);
			date.showdate(select_date);
			//AnchorPane root = FXMLLoader.load(getClass().getResource("Summary.fxml"));
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		}
		else
		{
			warning.setText("Please select date correctly");
		}
	}
	public void switchToCart(ActionEvent event) throws IOException{
		String username = user.getText();
		FXMLLoader loader = new FXMLLoader(getClass().getResource("cart.fxml"));
		AnchorPane root = loader.load();
		cart crt = loader.getController();
		crt.displayName(username);
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
}
