package application;
import java.io.IOException;
import javafx.scene.control.DatePicker;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class carrier {
	private Stage stage;
	private Scene scene;
	private Parent root;
	    
	    @FXML
	    private DatePicker myDatePicker;

	    @FXML
	    private Label myLabel; 
	    
	    @FXML
	    private Button date;
	
	    @FXML
	    private Button Log_out;

	    @FXML
	    private ListView<String> orders;
	    
	    @FXML
	    private ListView<String> deliver;
	    
	    @FXML
	    private ListView<String> deliveredorders;

	    @FXML
	    private Button select;

	    @FXML
	    private Label usrername;

	    @FXML
	    private Label attention;
	    
	    @FXML
	    private Label warn_date;

	    
	    private LocalDate minDate = LocalDate.now();
		private LocalDate maxDate = LocalDate.now().plusDays(2);
		
		public void displayName(String un) {
			usrername.setText(un);
			
		}
	    
	    public void checkDate(ActionEvent event) {
			  
			LocalDate myDate = myDatePicker.getValue();
			int datechecker =  myDate.compareTo(maxDate); 
			int datechecker2 = minDate.compareTo(myDate);
			String ChosenDate = null;
			if(datechecker < 1) {
				ChosenDate = myDate.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
				myLabel.setText(ChosenDate);
			}else if(datechecker == 0) {	
				ChosenDate = myDate.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
				myLabel.setText(ChosenDate);;
			}else {
				myLabel.setText("Invalid Date");
			}
			if(datechecker2 > 0) {
				myLabel.setText("Invalid Date");
			}
			
		}
	    
	    public void initialize()
	    {
	    	List<String> selected = new ArrayList<>();
	    	String the_carrier=usrername.getText();
	    	
	    	//This part is for showing not selected orders
	    	List<String> order = new ArrayList<>();
	    	try {
	    		Connection connect1= DriverManager.getConnection("jdbc:mysql://localhost:3306/finalizeorder", "root", "Hh123456!");
	             PreparedStatement preparedStatement1= connect1.prepareStatement("SELECT * FROM orderinfos WHERE isselected='0' ");
	             ResultSet resultSet1=preparedStatement1.executeQuery();
	             while(resultSet1.next())
	             {
	            	 int idorder=resultSet1.getInt("idorderinfos");
	            	 String Name= resultSet1.getString("name");
	            	 String Surname=resultSet1.getString("surname");
	            	 String Address= resultSet1.getString("adress");
	            	 String Phone= resultSet1.getString("phone");
	            	 String product= resultSet1.getString("products");
	            	 String kilos= resultSet1.getString("kg");
	            	 Double taxes= resultSet1.getDouble("tax");
	            	 Double tax_exc= resultSet1.getDouble("tax_exclude");
	            	 Double total= resultSet1.getDouble("total_price");
	            	 String tax_to_string = String.format("%.2f", taxes);
	                 String convert_exclude = String.format("%.2f", tax_exc);
	                 String total_price = String.format("%.2f", total);
	                 String date= resultSet1.getString("delivery_day");
	            	 order.add(String.valueOf(idorder)+ " Name: "+ Name+" Surname: "+ Surname+ " Address: "+ Address+ " Phone no: "+ Phone+ " Products: "+ product+ "Kilos respectively "+kilos+ " tax: "+tax_to_string+ " without tax "+ convert_exclude+ " total: "+ total_price +" delivery date: "+date );
	            	 
	             }
	             resultSet1.close();
	             preparedStatement1.close();
	             connect1.close();
	    	}catch (SQLException g) {
                g.printStackTrace();
            }
	    	orders.getItems().addAll(order);
	    	
	    	try {
	    		Connection connect2= DriverManager.getConnection("jdbc:mysql://localhost:3306/finalizeorder", "root", "Hh123456!");
	             PreparedStatement preparedStatement2= connect2.prepareStatement("SELECT * FROM orderinfos WHERE isselected='1' ");
	             ResultSet resultSet2=preparedStatement2.executeQuery();
	             if(resultSet2.next())
	             {
		            	 int order_id=resultSet2.getInt("idorderinfos");
		            	 String Name= resultSet2.getString("name");
		            	 String carrier = resultSet2.getString("carrier's name");
		            	 String Surname=resultSet2.getString("surname");
		            	 String Address= resultSet2.getString("adress");
		            	 String Phone= resultSet2.getString("phone");
		            	 String product= resultSet2.getString("products");
		            	 String kilos= resultSet2.getString("kg");
		            	 Double taxes= resultSet2.getDouble("tax");
		            	 Double tax_exc= resultSet2.getDouble("tax_exclude");
		            	 Double total= resultSet2.getDouble("total_price");
		            	 String tax_to_string = String.format("%.2f", taxes);
		                 String convert_exclude = String.format("%.2f", tax_exc);
		                 String total_price = String.format("%.2f", total);
		                 String date= resultSet2.getString("delivery_day");
		            	 selected.add(String.valueOf(order_id)+" "+carrier+ " Name: "+ Name+" Surname: "+ Surname+ " Address: "+ Address+ " Phone no: "+ Phone+ " Products: "+ product+ "Kilos respectively "+kilos+ " tax: "+tax_to_string+ " without tax "+ convert_exclude+ " total: "+ total_price +" delivery date: "+date );
	            	 
	             }
	             resultSet2.close();
	             preparedStatement2.close();
	             connect2.close();
	    	}catch (SQLException g) {
                g.printStackTrace();
            }
	    	deliver.getItems().addAll(selected);
	    	
	    	
	    	List<String> setteddate = new ArrayList<>();
	    	try {
	    	Connection connect3= DriverManager.getConnection("jdbc:mysql://localhost:3306/finalizeorder", "root", "Hh123456!");
            PreparedStatement preparedStatement3= connect3.prepareStatement("SELECT * FROM orderinfos WHERE isselected='2' ");
            ResultSet resultSet3=preparedStatement3.executeQuery();
            while(resultSet3.next())
            {
           	 int idorder=resultSet3.getInt("idorderinfos");
           	 String Name= resultSet3.getString("name");
           	 String carrier = resultSet3.getString("carrier's name");
           	 String Surname=resultSet3.getString("surname");
           	 String Address= resultSet3.getString("adress");
           	 String Phone= resultSet3.getString("phone");
           	 String product= resultSet3.getString("products");
           	 String kilos= resultSet3.getString("kg");
           	 Double taxes= resultSet3.getDouble("tax");
           	 Double tax_exc= resultSet3.getDouble("tax_exclude");
           	 Double total= resultSet3.getDouble("total_price");
           	 String tax_to_string = String.format("%.2f", taxes);
             String convert_exclude = String.format("%.2f", tax_exc);
             String total_price = String.format("%.2f", total);
             String date= resultSet3.getString("delivery_day");
           	 setteddate.add(String.valueOf(idorder)+ " Name: "+ Name+" Surname: "+ Surname+ " Address: "+ Address+ " Phone no: "+ Phone+ " Products: "+ product+ "Kilos respectively "+kilos+ " tax: "+tax_to_string+ " without tax "+ convert_exclude+ " total: "+ total_price +" delivery date: "+date+ "Carrier:"+carrier );
           	 
            }
            resultSet3.close();
            preparedStatement3.close();
            connect3.close();
   	   }catch (SQLException g) {
           g.printStackTrace();
       }
      	deliveredorders.getItems().addAll(setteddate);
	    	 
	    }
	    
	    public void selection(ActionEvent event) {
	    	String select = orders.getSelectionModel().getSelectedItem();
	    	if (select != null) {
	    	    String[] parts = select.split(" ");
	    	    int idorder = Integer.parseInt(parts[0]);	    
	    	    String username = usrername.getText();
	    	    try {
	    	        Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalizeorder", "root", "Hh123456!");
	    	        PreparedStatement update = connect.prepareStatement("UPDATE orderinfos SET isselected = '1', `carrier's name` = ? WHERE idorderinfos = ?");
	    	        update.setString(1, username);
	    	        update.setInt(2, idorder);
	    	        update.executeUpdate();
	    	        attention.setText("Successfully selected");
	    	        connect.close();
	    	        update.close();
	    	    } catch (SQLException exception) {
	    	        exception.printStackTrace();
	    	    }
	    	    orders.getItems().remove(select);
	    	    attention.setText("Successfully selected");
	    	} else {
	    	    attention.setText("Error");
	    	}
	    }
	    	
	    	
	    
	    public void setDate (ActionEvent event)
	    {
	    	String select = deliver.getSelectionModel().getSelectedItem();
	    	if (select != null) {
	    	    String[] parts = select.split(" ");
	    	    String carrier = parts[1];
	    	    int idorder = Integer.parseInt(parts[0]);
	    	    String username = usrername.getText();
	    	    String date=myLabel.getText();
	    	    if(date=="Date" || date=="Invalid Date")
	    	    {
	    	    	warn_date.setText("You cannot do that");
	    	    }
	    	    else if(!username.equals(carrier))
	    	    {
	    	    	warn_date.setText("This is not your order");
	    	    }
	    	    else
	    	    {
	    	    	try {
		    	        Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalizeorder", "root", "Hh123456!");
		    	        PreparedStatement update = connect.prepareStatement("UPDATE orderinfos SET isselected = '2', delivery_day = ? WHERE idorderinfos = ?");
		    	        update.setString(1, date);
		    	        update.setInt(2, idorder);
		    	        update.executeUpdate();
		    	        warn_date.setText("Successfully selected");
		    	        connect.close();
		    	        update.close();
		    	    } catch (SQLException exception) {
		    	        exception.printStackTrace();
		    	    }
		    	    deliver.getItems().remove(select);
		    	    warn_date.setText("Successfully selected");
		    	}
	    	    
	    	}
	    	else
	    	{
	    		warn_date.setText("Error");
	    	}
	    }

	    public void loggingout(ActionEvent event)throws IOException {
	    	AnchorPane root = FXMLLoader.load(getClass().getResource("hello-view.fxml"));
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
	    }

		

	

}
