package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;


public class summary {
	@FXML
    private ListView<String> choices;

    @FXML
    private Label date;

    @FXML
    private Button go_back;

    @FXML
    private Label price;

    @FXML
    private Label username;
    
    private Stage stage;
	private Scene scene;
	private AnchorPane root;
    
    public void showdate(String date2) {
		
	     date.setText(date2);
	}


	public void displayName(String username2) {
		username.setText(username2);
	}
    public void initialize()
    {
    	List<String> selection = new ArrayList<>();
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/orderinfo", "root", "Hh123456!");
            PreparedStatement ps = con.prepareStatement("SELECT * FROM selectlist ");
            ResultSet res = ps.executeQuery();
            
            double result=0;
            
            while(res.next())
            {
            	double getPrice= res.getDouble("totalprice");
            	double kilo= res.getDouble("kg");
            	String names= res.getString("productname");
            	String formatPrice = String.format("%.2f", getPrice);
                String formatKilo = String.format("%.2f", kilo);
            	selection.add("Names "+names+ " Prices" + formatPrice + " Kilos: "+ formatKilo);
            	result+= getPrice;
            }
            price.setText(String.format("%.2f", result));
            
		}catch (SQLException d) {
            d.printStackTrace();
        }
		choices.getItems().addAll(selection);
    }

    
    public void back(ActionEvent event) throws IOException {
    	String users = username.getText();
		FXMLLoader loader = new FXMLLoader(getClass().getResource("DnP.fxml"));
		AnchorPane root = loader.load();
		DnPControl control = loader.getController();
		control.displayName(users);
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
    }


	

	
}
