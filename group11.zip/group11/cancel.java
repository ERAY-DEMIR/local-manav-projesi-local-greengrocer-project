package application;

import java.io.IOException;
import javafx.scene.control.DatePicker;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;


public class cancel {
	    
	    private Stage stage;
	    private Scene scene;
	    private Parent root;

        @FXML
        private Button Catalog;

        @FXML
        private Label Username;

        @FXML
        private Button delete;

        @FXML
        private ListView<String> orderofuser;

        @FXML
        private Label warn_cancel;
        
        
        public void displayName(String username2) {
			Username.setText(username2);		
		}
        
        public void initialize()
        {
        	List<String> orders = new ArrayList<>();
        	String user = Username.getText().trim();
        	
        	try {
        	 Connection connect1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalizeorder", "root", "Hh123456!");
        	 PreparedStatement preparedStatement1 = connect1.prepareStatement("SELECT * FROM orderinfos ");        	 
        	  ResultSet resultSet1 = preparedStatement1.executeQuery();
        	    while (resultSet1.next()) {
        	    	    String User= resultSet1.getString("username");
	        	        int idorder = resultSet1.getInt("idorderinfos");
	        	        String product = resultSet1.getString("products");
	        	        String kilos = resultSet1.getString("kg");
	        	        orders.add(String.valueOf(idorder)+" "+User+" "+product+" "+kilos); 
        	            }
        	connect1.close();    
        	    
        	}catch (SQLException g) {
                g.printStackTrace();
            }
        	orderofuser.getItems().addAll(orders);
        }
        
        	
        
        public void cancel(ActionEvent event) {
        	String select = orderofuser.getSelectionModel().getSelectedItem();
	    	if (select != null) {
	    	    String[] parts = select.split(" ");
	    	    String U = parts[1];   
	    	    String username = Username.getText();
	    	    if(!(username.equals(U)))
	    	    {
	    	    	warn_cancel.setText("This is not your order");
	    	    }
	    	    else
	    	    {
	    	    	int idOrder = Integer.parseInt(parts[0]);
	    	    	String products = parts[2];
	    	        String kilos = parts[3];
	    	        String[] productArray = products.split(",");
	    	        String[] kilogram = kilos.split(",");

	    	        try {
	    	            Connection connect1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/cancel", "root", "Hh123456!");
	    	            for (int i = 0; i < productArray.length; i++) {
	    	                String product = productArray[i];
	    	                double kilo = Double.parseDouble(kilogram[i]);
	    	                PreparedStatement inserttodelete = connect1.prepareStatement("INSERT INTO deleteorder (productname, kg) VALUES (?, ?)");
	    	                inserttodelete.setString(1, product);
	    	                inserttodelete.setDouble(2, kilo);
	    	                inserttodelete.executeUpdate();
	    	            }
	    	            connect1.close();
	    	        } catch (SQLException e) {
	    	            e.printStackTrace();
	    	        }

	    	    	try {
	    	    		 Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/products", "root", "Hh123456!");
	    	   		     PreparedStatement ps = connect.prepareStatement("SELECT * FROM producttable");
	    	   		     ResultSet rs = ps.executeQuery(); 

	    	   		    while (rs.next()) {
	    	   		        String name = rs.getString("product_name");
	    	   		        Double price = rs.getDouble("price");
	    	   		        Double kg = rs.getDouble("stock");
	    	   		        Double thres = rs.getDouble("threshold");

	    	   		        try {
	    	   		        	 Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/cancel", "root", "Hh123456!");
	    	   		             PreparedStatement pes = c.prepareStatement("SELECT * FROM deleteorder ");
	    	   		             ResultSet res = pes.executeQuery();
	    	   		        	 PreparedStatement update = connect.prepareStatement("UPDATE producttable SET stock = ?, price = ?, threshold = ? WHERE product_name = ?");
	    	   		             PreparedStatement select1 = c.prepareStatement("SELECT * FROM deleteorder WHERE productname = ?"); 
	    	   		             select1.setString(1, name);
		    	   		          try (ResultSet result = select1.executeQuery()) {
		    	   		                if (result.next()) {
		    	   		                    Double kilo = result.getDouble("kg");
		    	   		                    update.setDouble(1, kg + kilo);
		    	   		                    update.setDouble(2, price);
		    	   		                    update.setDouble(3, (kg+kilo)/2);
		    	   		                    update.setString(4, name);
		    	   		                    update.executeUpdate();
		    	   		                }
		    	   		          }
		    	   		             catch (SQLException except) {
		    	   	   		   		    except.printStackTrace();
		    	   	   		   		}
		    	   		          c.close();
		    	   	   		    }catch (SQLException exception) {
			    	   	   		    exception.printStackTrace();
			    	   	   		}
		    	   	   		    
		    	   	   		} 
	    	   		  connect.close();
	    	    	  }catch (SQLException e) {
		    	   	   		    e.printStackTrace();
		    	   	   		}
	    	    	
	    	    	   try
	    	    	   {
	    	    		   Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalizeorder", "root", "Hh123456!");
	    	    		    PreparedStatement deleteOrder = connect.prepareStatement("DELETE FROM orderinfos WHERE idorderinfos = ? AND username = ?");
	    	    		    deleteOrder.setInt(1, idOrder);
	    	    		    deleteOrder.setString(2, username);
	    	    		    deleteOrder.executeUpdate();

	    	    	   }catch (SQLException exc) {
	    	   	   		    exc.printStackTrace();
	    	   	   		}
	    	    	   try
	    	    	   {
	    	    		   Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cancel", "root", "Hh123456!");
	    	               PreparedStatement ps = con.prepareStatement("DELETE FROM deleteorder ");
	    	               ps.executeUpdate();
	    	               warn_cancel.setText("Succesfully deleted");
	    	    	   }catch (SQLException exc) {
	    	   	   		    exc.printStackTrace();
	    	   	   		}
	    	    	    orderofuser.getItems().remove(select);
	    	    	    
	    	    	}
	    	    	
	    	  } 
	    	
        }

        
        public void catalog(ActionEvent event) throws IOException {
        	String username = Username.getText();
			FXMLLoader loader = new FXMLLoader(getClass().getResource("Catalog.fxml"));
			AnchorPane root = loader.load();
			CatalogController control = loader.getController();
			control.displayName(username);
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.show(); 	
        }

    }


