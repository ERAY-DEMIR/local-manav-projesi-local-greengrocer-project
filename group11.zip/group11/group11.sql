SELECT *FROM producttable;










