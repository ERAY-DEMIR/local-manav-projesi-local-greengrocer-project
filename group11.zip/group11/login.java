package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.event.ActionEvent;


import java.io.IOException;
import java.sql.*;


public class login {
    public  login()
    {

    }
    private Stage stage;
    private Scene scene;
    private AnchorPane root;
    @FXML
    private Button log_in;

    @FXML
    private Button register;

    @FXML
    private TextField username;

    @FXML
    private PasswordField password;

    @FXML
    private Label wrong_enter;

    public void log_in_check (ActionEvent event ) throws IOException
    {
        if(username.getText().toString().equals("admin")&& password.getText().toString().equals("13579"))
        {
            wrong_enter.setText("Entered to system as owner. Directed to owner interface");
            openownerContent(event);
        }
        else if (username.getText().isEmpty() && password.getText().isEmpty())
        {
            wrong_enter.setText("Enter data: ");
        }
        else if(!(username.getText().toString().equals("admin")&& password.getText().toString().equals("13579")))
        {
        	String the_carrier_user=username.getText();
        	String the_carrier_pass=password.getText();
        	try {
        	 Connection connect1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/carriers", "root", "Hh123456!");
	    	 PreparedStatement check = connect1.prepareStatement("SELECT username FROM carrierlist WHERE username = ? AND password = ?");
	    	 check.setString(1, the_carrier_user);
	    	 check.setString(2, the_carrier_pass);
	    	 ResultSet resultset = check.executeQuery();
	    	 if(resultset.next())
	    	 {
	    		 wrong_enter.setText("Entered to system as carrier. Directed to carrier interface");
	             opencarrierContent(event);
	    	 }
	    	 else 
	         {
	             try
	             {
	                 Connection connect= DriverManager.getConnection("jdbc:mysql://localhost:3306/infos", "root", "Hh123456!");
	                 PreparedStatement preparedStatement= connect.prepareStatement("SELECT username ,password FROM registertable WHERE username = ? AND password = ?");
	                 preparedStatement.setString(1, username.getText());
	                 preparedStatement.setString(2, password.getText());
	                 ResultSet resultSet=preparedStatement.executeQuery();

	                     while (resultSet.next()) {
	                         //A  User exists in the database
	                         String storedPass = resultSet.getString("password"); // Get the stored passwords from database to chech
	                         String storedUser = resultSet.getString("username");
	                         if (password.getText().equals(storedPass) && username.getText().equals(storedUser)) {
	                             wrong_enter.setText("Successful directed to customer page ");
	                             String un = username.getText();
	                             FXMLLoader loader = new FXMLLoader(getClass().getResource("Catalog.fxml"));
	                             AnchorPane root = loader.load();
	                             CatalogController catalogController = loader.getController();
	                             catalogController.displayName(un);                            
	                             stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	                             scene = new Scene(root);
	                             stage.setScene(scene);
	                             stage.show();
	                         } else {
	                             // Passwords don't match
	                             wrong_enter.setText("Incorrect password");
	                         }

	                     }
	                     /*if(!resultSet.next()) {
	                         // if User not found in the database it opens user didn't registered. Thus register page opens.
	                         wrong_enter.setText("Not registered");
	                         registercheck(event);
	                     }*/
	                     connect.close();
	                     preparedStatement.close();
	                     resultSet.close();
	             }catch (SQLException e){
	             	
	                 e.printStackTrace();
	             }
	         }

            connect1.close();
            check.close();
            resultset.close();
        	}catch (SQLException g) {
                g.printStackTrace();
            }
        }
        
    }
    public void registercheck (ActionEvent event ) throws IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("register.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setTitle("Register");
    }
    public void openownerContent(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("owner.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setTitle("Owner");
    }
    public void opencarrierContent(ActionEvent event) throws IOException {
    	
    	String un = username.getText();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("carrier.fxml"));
        AnchorPane root = loader.load();
        carrier c = loader.getController();
        c.displayName(un);                            
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

}
