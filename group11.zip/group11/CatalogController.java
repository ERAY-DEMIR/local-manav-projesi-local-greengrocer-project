package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import java.sql.*;

public class CatalogController{
	
	private Stage stage;
	private Scene scene;
	private Parent root;
	
	@FXML
	Label nameLabel;
	
	@FXML
	Label appleprice;
	
	@FXML
	Label bananaprice;
	
	@FXML
	Label cherryprice;
	
	@FXML
	Label kiwiprice;
	
	@FXML
	Label mandprice;
	
	@FXML
	Label melonprice;
	
	@FXML
	Label orangeprice;
	
	@FXML
	Label peachprice;
	
	@FXML
	Label pearprice;
	
	@FXML
	Label plumprice;
	
	@FXML
	Label pomeprice;
	
	@FXML
	Label wmelonprice;
	
	@FXML
	Label artiprice;
	
	@FXML
	Label brocoprice;
	
	@FXML
	Label cabprice;
	
	@FXML
	Label carrotprice;
	
	@FXML
	Label cornprice;
	
	@FXML
	Label eggprice;
	
	@FXML
	Label lettuceprice;
	
	@FXML
	Label onionprice;
	
	@FXML
	Label pumprice;
	
	@FXML
	Label peaprice;
	
	@FXML
	Label radprice;
	
	@FXML
	Label zucprice;
	
	@FXML
	TextField apple_kg;
	
	@FXML
	TextField banana_kg;
	
	@FXML
	TextField cherry_kg;
	
	@FXML
	TextField kiwi_kg;
	
	@FXML
	TextField mand_kg;
	
	@FXML
	TextField melon_kg;
	
	@FXML
	TextField orange_kg;
	
	@FXML
	TextField peach_kg;
	
	@FXML
	TextField pear_kg;
	
	@FXML
	TextField plum_kg;
	
	@FXML
	TextField pome_kg;
	
	@FXML
	TextField wmelon_kg;
	
	@FXML
	TextField arti_kg;
	
	@FXML
	TextField broco_kg;
	
	@FXML
	TextField cab_kg;
	
	@FXML
	TextField carrot_kg;
	
	@FXML
	TextField corn_kg;
	
	@FXML
	TextField egg_kg;
	
	@FXML
	TextField lettuce_kg;
	
	@FXML
	TextField onion_kg;
	
	@FXML
	TextField pump_kg;
	
	@FXML
	TextField peas_kg;
	
	@FXML
	TextField radish_kg;
	
	@FXML
	TextField zucc_kg;
	
	@FXML
	Button add_apple;
	
	@FXML
	Button add_banana;
	
	@FXML
	Button add_cherry;
	
	@FXML
	Button add_kiwi;
	
	@FXML
	Button add_mand;
	
	@FXML
	Button add_melon;
	
	@FXML
	Button add_orange;
	
	@FXML
	Button add_peach;
	
	@FXML
	Button add_pear;
	
	@FXML
	Button add_plum;
	
	@FXML
	Button add_pome;
	
	@FXML
	Button add_wmelon;
	
	@FXML
	Button add_arti;
	
	@FXML
	Button add_broco;
	
	@FXML
	Button add_cab;
	
	@FXML
	Button add_carrot;
	
	@FXML
	Button add_corn;
	
	@FXML
	Button add_egg;

	@FXML
	Button add_lettuce;
	
	@FXML
	Button add_onion;
	
	@FXML
	Button add_pump;
	
	@FXML
	Button add_peas;
	
	@FXML
	Button add_radish;
	
	@FXML
	Button add_zuc;
	
	@FXML
	Label warn_apple;  
	
	@FXML
	Label warn_banana;  
	
	@FXML
	Label warn_cherry;
	
	@FXML
	Label warn_kiwi;
	
	@FXML
	Label warn_mand;
	
	@FXML
	Label warn_melon;
	
	@FXML
	Label warn_orange;
	
	@FXML
	Label warn_peach;
	
	@FXML
	Label warn_pear;
	
	@FXML
	Label warn_plum;
	
	@FXML
	Label warn_pome;  
	
	@FXML
	Label warn_wmelon;  
	
	@FXML
	Label warn_arti;  
	
	@FXML
	Label warn_broco;
	
	@FXML
	Label warn_cab;
	
	@FXML
	Label warn_carrot;
	
	@FXML
	Label warn_corn;  
	
	@FXML
	Label warn_egg;
	
	@FXML
	Label warn_lettu;
	
	@FXML
	Label warn_onion;
	
	@FXML
	Label warn_pump;
	
	@FXML
	Label warn_peas;
	
	@FXML
	Label warn_radish;
	
	@FXML
	Label warn_zuc; 
	
	@FXML
     TextField name1kg;

    @FXML
    Button name2add;

    @FXML
    TextField name2kg;

    @FXML
    Button name3add;

    @FXML
    TextField name3kg;

    @FXML
    Button name4add;

    @FXML
    TextField name4kg;

    @FXML
    Button name5add;

    @FXML
    TextField name5kg;

    @FXML
    Button name6add;

    @FXML
    TextField name6kg;
    
    @FXML
    Label price1;

    @FXML
    Label price2;

    @FXML
    Label price3;

    @FXML
    Label price4;

    @FXML
    Label price5;

    @FXML
    Label price6;
    
    @FXML
    Label name1;
    
    @FXML
    Label name2;
    
    @FXML
    Label name3;
    
    @FXML
    Label name4;

    @FXML
    Label name5;
    
    @FXML
    Label name6;
    
    @FXML
    Label warningname1;

    @FXML
    Label warningname2;

    @FXML
    Label warningname3;

    @FXML
    Label warningname4;

    @FXML
    Label warningname5;

    @FXML
    Label warningname6; 
    
    @FXML
	Button prevorder;
	
	public void initialize() {
		try {
			 Connection connect= DriverManager.getConnection("jdbc:mysql://localhost:3306/products", "root", "Hh123456!");
			 java.sql.Statement smt= connect.createStatement();
			 ResultSet resultset=smt.executeQuery("SELECT product_name,price,stock FROM producttable");
			 while(resultset.next())
			 {
				 String name= resultset.getString("product_name");
				 Double prices= resultset.getDouble("price");
				 Double stocks= resultset.getDouble("stock");
				 if(name.equals("apple")|| name.equals("Apple"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 appleprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 appleprice.setText("Stock is 0 you cannot choose");
					 }
				 }
				 if(name.equals("banana")|| name.equals("Banana"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 bananaprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 bananaprice.setText("Stock is 0 you cannot choose");
					 }
				 }
				 if(name.equals("cherry")|| name.equals("Cherry"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 cherryprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 cherryprice.setText("Stock is 0 you cannot choose");
					 }
				 }
				 if(name.equals("kiwi")|| name.equals("Kiwi"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 kiwiprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 kiwiprice.setText("Stock is 0 you cannot choose");
					 }
				 }
				 if(name.equals("Mandarin")|| name.equals("mandarin"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 mandprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 mandprice.setText("Stock is 0 you cannot choose");
					 }
				 }
				 if(name.equals("melon")|| name.equals("Melon"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 melonprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 melonprice.setText("Stock is 0 you cannot choose");
					 }
				 }
				 if(name.equals("orange")|| name.equals("Orange"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 orangeprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 orangeprice.setText("Stock is 0 you cannot choose");
					 }
				 }
				 if(name.equals("peach")|| name.equals("Peach"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 peachprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 peachprice.setText("Stock is 0 you cannot choose");
					 }
				 }
				 if(name.equals("pear")|| name.equals("Pear"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 pearprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 pearprice.setText("Stock is 0 you cannot choose");
					 }
				 }
				 if(name.equals("plum")|| name.equals("Plum"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 plumprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 plumprice.setText("Stock is 0 you cannot choose");
					 }
				 }
				 if(name.equals("Pomegranate")|| name.equals("pomegranate"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 pomeprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 pomeprice.setText("Stock is 0 you cannot choose");
					 }
				 }
				 if(name.equals("Watermelon")|| name.equals("watermelon"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 wmelonprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 wmelonprice.setText("Stock is 0 you cannot choose");
					 }
				 }
				 if(name.equals("artichoke")|| name.equals("Artichoke"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 artiprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 artiprice.setText("Stock is 0 you cannot choose");
					 }
				 }
				 if(name.equals("broccoli")|| name.equals("Broccoli"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 brocoprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 brocoprice.setText("Stock is 0 you cannot choose");
					 }
				 }
				 
				 if(name.equals("cabbage")|| name.equals("Cabbage"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 cabprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 cabprice.setText("Stock is 0 you cannot choose");
					 }
				 }
				 if(name.equals("carrot")|| name.equals("Carrot"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 carrotprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 carrotprice.setText("Stock is 0 you cannot choose");
					 }
				 }
				 if(name.equals("corn")|| name.equals("Corn"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 cornprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 cornprice.setText("Stock is 0 you cannot choose");
					 }
				 }
				 if(name.equals("eggplant")|| name.equals("Eggplant"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 eggprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 eggprice.setText("Stock is 0 you cannot choose");
					 }
				 }
				 if(name.equals("lettuce")|| name.equals("Lettuce"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 lettuceprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 lettuceprice.setText("Stock is 0 you cannot choose");
					 }
				 }
				 if(name.equals("onion")|| name.equals("Onion"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 onionprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 onionprice.setText("Stock is 0 you cannot choose");
					 }
				 }
				 if(name.equals("pumpkin")|| name.equals("Pumpkin"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 pumprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 pumprice.setText("Stock is 0 you cannot choose");
					 }
				 }
				 if(name.equals("peas")|| name.equals("Peas"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 peaprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 peaprice.setText("Stock is 0 you cannot choose");
					 }
				 }
				 if(name.equals("radish")|| name.equals("Radish"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 radprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 radprice.setText("Stock is 0 you cannot choose");
					 }
				 }
				 if(name.equals("zucchini")|| name.equals("Zucchini"))
				 {
					 if(!(stocks.equals(0.00)))
					 {
						 zucprice.setText(Double.toString(prices));
					 }
					 else
					 {
						 zucprice.setText("Stock is 0 you cannot choose");
					 }
				 } 
				  
			 }
			 connect.close();
	         resultset.close();
		}catch (SQLException e){
	        e.printStackTrace();
	    }
		
		try {
		    Connection connect1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/products", "root", "Hh123456!");
		    Statement smt1 = connect1.createStatement();
		    ResultSet resultSet1 = smt1.executeQuery("SELECT product_type, product_name, price, stock FROM producttable WHERE idproducttable > 24");

		    while (resultSet1.next()) {
		        String productType = resultSet1.getString("product_type");
		        String productName = resultSet1.getString("product_name");
		        double price = resultSet1.getDouble("price");
		        double stock = resultSet1.getDouble("stock");

		        if (productType.equals("Fruit"))
		        {
		            if (name1.getText().equals("Name1")) 
		            {
		                name1.setText(productName);
		                price1.setText(Double.toString(price));
		                if (stock == 0) {
		                    warningname1.setText("Stock is 0");
		                }
		            } 
		            else if (name2.getText().equals("Name2")) {
		                name2.setText(productName);
		                price2.setText(Double.toString(price));
		                if (stock == 0) {
		                    warningname2.setText("Stock is 0");
		                }
		            } 
		            else if (name3.getText().equals("Name3")) {
		                name3.setText(productName);
		                price3.setText(Double.toString(price));
		                if (stock == 0) {
		                    warningname3.setText("Stock is 0");
		                }
		            }
		        }
		        else {
		            if (name4.getText().equals("Name4")) {
		                name4.setText(productName);
		                price4.setText(Double.toString(price));
		                if (stock == 0) {
		                    warningname4.setText("Stock is 0");
		                }
		            } else if (name5.getText().equals("Name5")) {
		                name5.setText(productName);
		                price5.setText(Double.toString(price));
		                if (stock == 0) {
		                    warningname5.setText("Stock is 0");
		                }
		            } else if (name6.getText().equals("Name6")) {
		                name6.setText(productName);
		                price6.setText(Double.toString(price));
		                if (stock == 0) {
		                    warningname6.setText("Stock is 0");
		                }
		            }
		        }
		    }

		    connect1.close();
		    resultSet1.close();
		} catch (SQLException e) {
		    e.printStackTrace();
		}
		
	}

	
	public void displayName(String username){
		nameLabel.setText(username);
	}
	
	
	public void cart_apple (ActionEvent event ) throws IOException
    {
		addtoCart("Apple", apple_kg, warn_apple);
		
		
    }
	public void cart_banana (ActionEvent event ) throws IOException
    {
		addtoCart("Banana", banana_kg, warn_banana);
		
    }
	public void cart_cherry (ActionEvent event ) throws IOException
    {
		addtoCart("Cherry",cherry_kg,warn_cherry);
		
    }
	public void cart_kiwi (ActionEvent event ) throws IOException
    {
		addtoCart("Kiwi",kiwi_kg,warn_kiwi);
		
    }
	public void cart_mand (ActionEvent event ) throws IOException
    {
		addtoCart("Mandarin",mand_kg,warn_mand);
		
    }
	public void cart_melon (ActionEvent event ) throws IOException
    {
		addtoCart("Melon",melon_kg,warn_melon);
		
    }
	public void cart_orange (ActionEvent event ) throws IOException
    {
		addtoCart("Orange",orange_kg,warn_orange);
		
    }
	public void cart_peach (ActionEvent event ) throws IOException
    {
		addtoCart("Peach",peach_kg,warn_peach);
		
    }
	public void cart_pear (ActionEvent event ) throws IOException
    {
		addtoCart("Pear",pear_kg,warn_pear);
		
    }
	public void cart_plum (ActionEvent event ) throws IOException
    {
		addtoCart("Plum",plum_kg,warn_plum);
		
    }
	public void cart_pome (ActionEvent event ) throws IOException
    {
		addtoCart("Pomegranate",pome_kg,warn_pome);
		
    }
	public void cart_wmelon (ActionEvent event ) throws IOException
    {
		addtoCart("Watermelon",wmelon_kg,warn_wmelon);
		
    }
	public void cart_art (ActionEvent event ) throws IOException
    {
		addtoCart("Artichoke",arti_kg,warn_arti);
		
    }
	public void cart_broco (ActionEvent event ) throws IOException
    {
		addtoCart("Broccoli",broco_kg,warn_broco);
		
    }
	public void cart_cab (ActionEvent event ) throws IOException
    {
		addtoCart("Cabbage",cab_kg,warn_cab);
		
    }
	public void cart_carrot (ActionEvent event ) throws IOException
    {
		addtoCart("Carrot",carrot_kg,warn_carrot);
		
    }
	public void cart_corn (ActionEvent event ) throws IOException
    {
		addtoCart("Corn",corn_kg,warn_corn);
		
    }
	public void cart_egg (ActionEvent event ) throws IOException
    {
		addtoCart("Eggplant",egg_kg,warn_egg);
		
    }
	public void cart_lettuce (ActionEvent event ) throws IOException
    {
		addtoCart("Lettuce",lettuce_kg,warn_lettu);
		
    }
	public void cart_onion (ActionEvent event ) throws IOException
    {
		addtoCart("Onion",onion_kg,warn_onion);
		
    }
	public void cart_pump (ActionEvent event ) throws IOException
    {
		addtoCart("Pumpkin",pump_kg,warn_pump);
		
    }
	public void cart_peas (ActionEvent event ) throws IOException
    {
		addtoCart("Peas",peas_kg,warn_peas);
    }
	public void cart_radish (ActionEvent event ) throws IOException
    {
		addtoCart("Radish",radish_kg,warn_radish);
		
    }
	public void cart_zuc (ActionEvent event ) throws IOException
    {
		addtoCart("Zucchini",zucc_kg,warn_zuc);
		
    }
	
	
    public void fruitadd1(ActionEvent event) {
        if(name1.getText().toString().equals("Name1"))
        {
        	warningname1.setText("There is not a product");
        }
        else
        {
        	addtoCart(name1.getText().toString(),name1kg,warningname1);
        }
    }

    
    public void fruitadd2(ActionEvent event) {
    	if(name2.getText().toString().equals("Name2"))
        {
        	warningname2.setText("There is not a product");
        }
        else
        {
        	addtoCart(name2.getText().toString(),name2kg,warningname2);
        }
    }

    
    public void fruitadd3(ActionEvent event) {
    	if(name3.getText().toString().equals("Name3"))
        {
        	warningname3.setText("There is not a product");
        }
        else
        {
        	addtoCart(name3.getText().toString(),name3kg,warningname3);
        }
    }
    
    public void veg5add(ActionEvent event) {
    	if(name5.getText().toString().equals("Name5"))
        {
        	warningname5.setText("There is not a product");
        }
        else
        {
        	addtoCart(name5.getText().toString(),name5kg,warningname5);
        }
    }

    
    public void veg6add(ActionEvent event) {
    	if(name6.getText().toString().equals("Name6"))
        {
        	warningname6.setText("There is not a product");
        }
        else
        {
        	addtoCart(name6.getText().toString(),name6kg,warningname6);
        }
    }

    
    public void vegadd4(ActionEvent event) {
    	if(name4.getText().toString().equals("Name4"))
        {
        	warningname4.setText("There is not a product");
        }
        else
        {
        	addtoCart(name4.getText().toString(),name4kg,warningname4);
        }
    }

	public void addtoCart (String productName, TextField kgTextField, Label warnLabel)
	{		
		try {
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/products", "root", "Hh123456!");
        Statement statement = connection.createStatement();
        String kilo = kgTextField.getText();
        ResultSet resultSet = statement.executeQuery("SELECT price, stock FROM producttable WHERE product_name='" + productName + "'");
        double value=Double.parseDouble(kilo);
        if(resultSet.next())
        {
        	double stock = resultSet.getDouble("stock");
            double prices = resultSet.getDouble("price");
            if (value > stock) {
                warnLabel.setText("Not enough stock. Stock is: "+stock);
            }
            else if (stock==0)
            {
            	warnLabel.setText("You cannot select this product because stock is 0");
            }
            else if (value <=0) {
                warnLabel.setText("Enter a nonnegative number greater than 0");
            } 
            else {
            	double total = value * prices;
                Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/orderinfo", "root", "Hh123456!");
                PreparedStatement check = connect.prepareStatement("SELECT * FROM selectlist WHERE productname=?");
                check.setString(1, productName);
                ResultSet result = check.executeQuery();
                if(result.next())
                {
                	double getKg = result.getDouble("kg");
                    double getTotal = result.getDouble("totalprice");

                    PreparedStatement update = connect.prepareStatement("UPDATE selectlist SET kg=?, totalprice=? WHERE productname=?");
                    update.setDouble(1, getKg + value);
                    update.setDouble(2, getTotal + total);
                    update.setString(3, productName);
                    update.executeUpdate();
                    warnLabel.setText("Value added to cart successfully");
                    update.close();
                }
                else
                {
                	PreparedStatement insert = connect.prepareStatement("INSERT INTO selectlist (productname, kg, totalprice) VALUES (?, ?, ?)");
                    insert.setString(1, productName);
                    insert.setDouble(2, value);
                    insert.setDouble(3, total);
                    insert.executeUpdate();
                    warnLabel.setText("Value added to cart successfully");
                    insert.close();
                }
                connect.close();
            }
        }
        connection.close();
        resultSet.close();
		}catch (SQLException e){
	        e.printStackTrace();
		
	    }
	}
	public void switchToLogin(ActionEvent event) throws IOException{
		try {
	    	Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/orderinfo", "root", "Hh123456!");
	    	con.setAutoCommit(false);
	        PreparedStatement ps = con.prepareStatement("DELETE FROM selectlist ");
	        con.commit();
	        ps.executeUpdate();
			AnchorPane root = FXMLLoader.load(getClass().getResource("hello-view.fxml"));
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		}catch (SQLException e){
	        e.printStackTrace();		
	    }
	}
	
	public void switchToCart(ActionEvent event) throws IOException{ 
        String username = nameLabel.getText();
		FXMLLoader loader = new FXMLLoader(getClass().getResource("cart.fxml"));
		AnchorPane root = loader.load();
		cart cartController = loader.getController();
		cartController.displayName(username);
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show(); 		
		
	}
	
    public void cancelorder(ActionEvent event) throws IOException{
    	String username = nameLabel.getText();
		FXMLLoader loader = new FXMLLoader(getClass().getResource("Cancel.fxml"));
		AnchorPane root = loader.load();
		cancel c = loader.getController();
		c.displayName(username);
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show(); 
    }
}

