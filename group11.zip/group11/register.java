package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import java.io.IOException;
import java.sql.*;


public class register {
    @FXML
    private Button save;

    @FXML
    private TextField username;

    @FXML
    private TextField name;

    @FXML
    private TextField surname;

    @FXML
    private TextField email;

    @FXML
    private TextField address;

    @FXML
    private PasswordField password;

    @FXML
    private PasswordField pass_check;

    @FXML
    private Label error_check;

    @FXML
    private Label match;

    public void saving(ActionEvent event)throws IOException
    {
        String user= username.getText();
        String names=name.getText();
        String surnames=surname.getText();
        String mail= email.getText();
        String addr=address.getText();
        String pass= password.getText();
        String check= pass_check.getText();

        boolean a=pass.matches(".*[a-zA-Z].*") && pass.matches(".*\\d.*");
        if(a)
        {
            error_check.setText("strong password");
        }
        else
        {
            error_check.setText("weak please check");
        }
        if(!pass.equals(check))
        {
            match.setText("entered password wrong");
        }
        if(pass.equals(check) && a)
        {
            Connection connect=null;
            PreparedStatement Insert=null;
            PreparedStatement userexist=null;
            ResultSet resultSet=null;
            try
            {
                connect= DriverManager.getConnection("jdbc:mysql://localhost:3306/infos", "root", "Hh123456!");
                userexist= connect.prepareStatement("SELECT * FROM registertable Where username= ?");
                userexist.setString(1, String.valueOf(user));
                resultSet= userexist.executeQuery();
                if(resultSet.isBeforeFirst())
                {
                    error_check.setText("you cannot use this username");
                }
                else
                {
                    Insert= connect.prepareStatement("INSERT INTO registertable (username,password,email,address,name,surname) Values(?,?,?,?,?,?)");
                    Insert.setString(1,user);
                    Insert.setString(2,pass);
                    Insert.setString(3,mail);
                    Insert.setString(4,addr);
                    Insert.setString(5,names);
                    Insert.setString(6,surnames);

                    Insert.executeUpdate();
                    openlogin(event);
                }
            }catch(SQLException e){
                e.printStackTrace();
            }finally {
                if(resultSet!=null)
                {
                    try {
                        resultSet.close();
                    }catch (SQLException e){
                        e.printStackTrace();
                    }
                }
                if(userexist!=null)
                {
                    try {
                        userexist.close();
                    }catch (SQLException e){
                        e.printStackTrace();
                    }
                }
                if(Insert!=null)
                {
                    try {
                        Insert.close();
                    }catch (SQLException e){
                        e.printStackTrace();
                    }
                }
                if(connect!=null)
                {
                    try {
                        connect.close();
                    }catch (SQLException e){
                        e.printStackTrace();
                    }
                }
            }

        }
    }
    public void openlogin(ActionEvent event)throws IOException
    {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setTitle("Log in");
    }
}
