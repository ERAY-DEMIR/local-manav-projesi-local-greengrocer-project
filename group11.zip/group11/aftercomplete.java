package application;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ChoiceBox;
import java.time.LocalTime;
import java.sql.*;

public class aftercomplete {
	

    @FXML
    private Button updatestock;
   
    @FXML
    private Label Username;

    @FXML
    private Label warn_complete;
    
    private Stage stage;
	private Scene scene;
	private AnchorPane root;
	
	public void displayName(String username2) {
		Username.setText(username2);
		
	}
    
    public void deletecartandstockupdate(ActionEvent event)throws IOException {
    	
    	try {
    		 Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/products", "root", "Hh123456!");
   		     PreparedStatement ps = connect.prepareStatement("SELECT * FROM producttable");
   		     ResultSet rs = ps.executeQuery(); 

   		    while (rs.next()) {
   		        String name = rs.getString("product_name");
   		        Double price = rs.getDouble("price");
   		        Double kg = rs.getDouble("stock");
   		        Double thres = rs.getDouble("threshold");

   		        try {
   		        	 Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/orderinfo", "root", "Hh123456!");
   		             PreparedStatement pes = c.prepareStatement("SELECT * FROM selectlist ");
   		             ResultSet res = pes.executeQuery();
   		        	 PreparedStatement update = connect.prepareStatement("UPDATE producttable SET stock = ?, price = ?, threshold = ? WHERE product_name = ?");
   		             PreparedStatement select = c.prepareStatement("SELECT * FROM selectlist WHERE productname = ?"); 

   		            select.setString(1, name);

   		            try (ResultSet result = select.executeQuery()) {
   		                if (result.next()) {
   		                    Double kilo = result.getDouble("kg");
   		                    update.setDouble(1, kg - kilo);
   		                    if (kg - kilo <= thres) {
   		                        price *= 2;
   		                        thres = 0.0;
   		                    }
   		                    update.setDouble(2, price);
   		                    update.setDouble(3, thres);
   		                    update.setString(4, name);
   		                    update.executeUpdate();
   		                }
   		            }
   		            c.close();
   		        }catch (SQLException except) {
   		   		    except.printStackTrace();
   		   		}
   		    }
   		    connect.close();
   		} catch (SQLException e) {
   		    e.printStackTrace();
   		}
    	try
    	{
    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/orderinfo", "root", "Hh123456!");
            PreparedStatement ps = con.prepareStatement("DELETE FROM selectlist ");
            ps.executeUpdate();
            warn_complete.setText("Succesfully completed directed to log in page");
            AnchorPane root = FXMLLoader.load(getClass().getResource("hello-view.fxml"));
    		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    		scene = new Scene(root);
    		stage.setScene(scene);
    		stage.show();
        	}catch (SQLException d) {
                d.printStackTrace();
            
    	}
    	
    }

}
