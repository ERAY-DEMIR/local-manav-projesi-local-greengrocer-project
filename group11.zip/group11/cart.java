package application;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import java.sql.*;
import javafx.scene.control.ListView;


public class cart {
	
	private Stage stage;
	private Scene scene;
	private AnchorPane root;
    @FXML
     Label exclude_tax;

    @FXML
    Label total_tax;
    
    @FXML
    Button go_delivery;
    
    @FXML
    Button grocery;
    
    @FXML
    Label Username;
    
    @FXML
    Button Delete;
    @FXML
    Label warn_shopping;

    
    @FXML
    private ListView<String> select_list;
    
    @FXML
    private Label warn_delete;

    
    
    public void initialize() {
    	List<String> selection = new ArrayList<>();
    	try {
    	    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/orderinfo", "root", "Hh123456!");
    	    PreparedStatement ps = con.prepareStatement("SELECT * FROM selectlist ");
    	    ResultSet res = ps.executeQuery();

    	    while (res.next()) {
    	        double getPrice = res.getDouble("totalprice");
    	        double kilo = res.getDouble("kg");
    	        String name = res.getString("productname");

    	        // Open producttable and get stock and price for comparison
    	        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/products", "root", "Hh123456!");
    	        PreparedStatement producttable = connection.prepareStatement("SELECT stock, price FROM producttable WHERE product_name = ?");
    	        producttable.setString(1, name);
    	        ResultSet productTableResult = producttable.executeQuery();

    	        if (productTableResult.next()) {
    	            double stock = productTableResult.getDouble("stock");
    	            double price = productTableResult.getDouble("price");

    	            String formatPrice;

    	    
    	            if (kilo > stock) {
    	                // we need to Update kg as stock because we cannot give more than we have
    	                kilo = stock;
    	                getPrice = kilo * price; 
    	                PreparedStatement update = con.prepareStatement("UPDATE selectlist SET kg = ? WHERE productname = ?");
    	                update.setDouble(1, kilo);
    	                update.setString(2, name);
    	                update.executeUpdate();
    	                update.close();
    	            }
    	            formatPrice = String.format("%.2f", getPrice);
    	            String formatKilo = String.format("%.2f", kilo);

    	            selection.add(name + " Prices " + formatPrice + " Kilos: " + formatKilo);
    	        }

    	        productTableResult.close();
    	        producttable.close();
    	        connection.close();
    	    }
    	    con.close();
    	} catch (SQLException e) {
    	    e.printStackTrace();
    	}
		select_list.getItems().addAll(selection);
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/orderinfo", "root", "Hh123456!");
            PreparedStatement ps = con.prepareStatement("SELECT * FROM selectlist ");
            ResultSet res = ps.executeQuery();
            
            double result=0;
            
            while(res.next())
            {
            	double getPrice= res.getDouble("totalprice");
            	double kilo= res.getDouble("kg");
            	result+= getPrice;
            }
            double tax=result/5;
            total_tax.setText(Double.toString(tax));
            result-=tax;
            exclude_tax.setText(Double.toString(result));
            con.close();
		}catch (SQLException d) {
            d.printStackTrace();
        }
    }
    
    
    public void delete(ActionEvent event) {
    	
    	  String select= select_list.getSelectionModel().getSelectedItem();
    	  if(select==null)
    	  {
    		  warn_delete.setText("Select the product that you wanna delete");
    	  }
    	  else
    	  {
    		  String name= select.split(" Prices")[0];
    		  try {
    			  Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/orderinfo", "root", "Hh123456!");
    			  PreparedStatement ps = con.prepareStatement("DELETE FROM selectlist WHERE productname = ?");
    			  ps.setString(1, name);
    			  ps.executeUpdate();
    			  con.close();
    		  }catch (SQLException d) {
    	            d.printStackTrace();
    	        }
    		  select_list.getItems().remove(select);
    		  try {
    				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/orderinfo", "root", "Hh123456!");
    	            PreparedStatement ps = con.prepareStatement("SELECT * FROM selectlist ");
    	            ResultSet res = ps.executeQuery();
    	            
    	            double result=0;
    	            
    	            while(res.next())
    	            {
    	            	double getPrice= res.getDouble("totalprice");
    	            	double kilo= res.getDouble("kg");
    	            	result+= getPrice;
    	            }
    	            double tax=result/5;
    	            total_tax.setText(Double.toString(tax));
    	            result-=tax;
    	            exclude_tax.setText(Double.toString(result));
    	            con.close();
    			}catch (SQLException d) {
    	            d.printStackTrace();
    	        }
    	  
    	  }
    	  
    	
    }
    
    public void switchToScene2(ActionEvent event) throws IOException {
		    	String username = Username.getText();
				FXMLLoader loader = new FXMLLoader(getClass().getResource("Catalog.fxml"));
				AnchorPane root = loader.load();
				CatalogController control = loader.getController();
				control.displayName(username);
				stage = (Stage)((Node)event.getSource()).getScene().getWindow();
				scene = new Scene(root);
				stage.setScene(scene);
				stage.show(); 	
            }
    	
	
    public void opendelivery(ActionEvent event) throws IOException {
    	
    	try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/orderinfo", "root", "Hh123456!");
            PreparedStatement ps = con.prepareStatement("SELECT * FROM selectlist ");
            ResultSet res = ps.executeQuery();
            if(!res.next())
            {
            	warn_shopping.setText("You didn't select any product");
            }
            else
            {
		    	String username = Username.getText();
				FXMLLoader loader = new FXMLLoader(getClass().getResource("DnP.fxml"));
				AnchorPane root = loader.load();
				DnPControl control = loader.getController();
				control.displayName(username);
				stage = (Stage)((Node)event.getSource()).getScene().getWindow();
				scene = new Scene(root);
				stage.setScene(scene);
				stage.show(); 	
            }
    	}catch (SQLException d) {
            d.printStackTrace();
        }
	
	}
    public void displayName(String username){
		Username.setText(username);
	}
    
}