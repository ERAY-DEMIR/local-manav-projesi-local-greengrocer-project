package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;


public class Orders {
	    @FXML
	    private ListView<String> allorders;

	    @FXML
	    private Button menu;
	    
	    private Stage stage;
		private Scene scene;
		private Parent root;
	    
	    public void initialize()
	    {
	    	List<String> order = new ArrayList<>();
	    	try {
	    		Connection connect1= DriverManager.getConnection("jdbc:mysql://localhost:3306/finalizeorder", "root", "Hh123456!");
	             PreparedStatement preparedStatement1= connect1.prepareStatement("SELECT * FROM orderinfos ");
	             ResultSet resultSet1=preparedStatement1.executeQuery();
	             while(resultSet1.next())
	             {
	            	 String Name= resultSet1.getString("name");
	            	 String Surname=resultSet1.getString("surname");
	            	 String Address= resultSet1.getString("adress");
	            	 String Phone= resultSet1.getString("phone");
	            	 String product= resultSet1.getString("products");
	            	 String kilos= resultSet1.getString("kg");
	            	 Double taxes= resultSet1.getDouble("tax");
	            	 Double tax_exc= resultSet1.getDouble("tax_exclude");
	            	 Double total= resultSet1.getDouble("total_price");
	            	 String tax_to_string = String.format("%.2f", taxes);
	                 String convert_exclude = String.format("%.2f", tax_exc);
	                 String total_price = String.format("%.2f", total);
	                 String date= resultSet1.getString("delivery_day");
	            	 order.add("Name: "+ Name+" Surname: "+ Surname+ " Address: "+ Address+ " Phone no: "+ Phone+ " Products: "+ product+ "Kilos respectively "+kilos+ " tax: "+tax_to_string+ " without tax "+ convert_exclude+ " total: "+ total_price +" delivery date: "+date );
	            	 
	             }
	             resultSet1.close();
	             preparedStatement1.close();
	             connect1.close();
	    	}catch (SQLException g) {
                g.printStackTrace();
            }
	    	allorders.getItems().addAll(order);
	    }
	    

	    public void go_menu(ActionEvent event) throws IOException {
	    	AnchorPane root = FXMLLoader.load(getClass().getResource("owner.fxml"));
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.show();   
	    }
}
